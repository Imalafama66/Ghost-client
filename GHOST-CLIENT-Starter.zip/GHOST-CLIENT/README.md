# GHOST CLIENT — Starter de plataforma

Monorepo inicial para desarrollar la tienda pública, el panel administrativo y la app Android de GHOST CLIENT.

## Incluye
- Web Next.js + TypeScript + Tailwind.
- Tienda pública responsive con descargas configurables.
- Panel `/admin` con navegación y métricas conectables.
- API inicial para versiones y configuración pública.
- Esquema Prisma/PostgreSQL para usuarios, productos, versiones, compras, licencias, descargas y contenido.
- Proyecto Android nativo Kotlin + Jetpack Compose como punto de partida.
- Diseño oscuro con acentos morados, glassmorphism y animaciones ligeras.

## Requisitos
- Node.js 20+
- npm 10+
- PostgreSQL 15+
- Java 17 y Android Studio (para Android)

## Ejecutar la web
```bash
cd apps/web
cp .env.example .env
npm install
npm run dev
```
Abre http://localhost:3000

El frontend funciona con contenido de demostración claramente marcado. Las descargas reales se habilitan al crear registros de versiones y configurar almacenamiento privado/público en el backend.

## Base de datos
```bash
cd apps/web
npx prisma generate
npx prisma migrate dev --name init
```
Configura `DATABASE_URL` en `.env` antes de ejecutar migraciones.

## Android
Abre `apps/android` desde Android Studio y sincroniza Gradle. Es un shell inicial de la app; requiere conectar las pantallas y llamadas a API antes de distribuirla.

## Seguridad y producción
Este starter NO incluye todavía una pasarela de pago activa, publicación en Google Play, verificación real de licencias ni almacenamiento de archivos configurado. No simula esas operaciones.
Antes de producción:
1. Implementar autenticación con proveedor probado, verificación de correo y recuperación.
2. Proteger `/admin` en servidor con roles RBAC.
3. Implementar webhooks firmados del proveedor de pagos.
4. Guardar archivos Premium en bucket privado y emitir URLs temporales tras validar licencia.
5. Añadir rate limiting, auditoría, backups, pruebas y monitoreo.
6. Completar política de privacidad, términos y requisitos de Google Play.

## Estructura
- `apps/web`: aplicación Next.js y API inicial.
- `apps/android`: aplicación Android Kotlin.
- `docs`: arquitectura y lista de siguientes pasos.
