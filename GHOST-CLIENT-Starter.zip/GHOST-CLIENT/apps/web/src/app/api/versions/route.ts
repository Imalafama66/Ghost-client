import { NextResponse } from 'next/server';
// Endpoint provisional: sustituir por consulta Prisma y publicar solo versiones disponibles.
export async function GET() { return NextResponse.json({ items: [], message: 'No hay versiones publicadas. Configúralas desde el administrador.' }); }
