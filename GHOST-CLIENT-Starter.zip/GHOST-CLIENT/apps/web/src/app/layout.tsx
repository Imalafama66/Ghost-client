import './globals.css';
import type { Metadata } from 'next';
export const metadata: Metadata = { title: 'GHOST CLIENT — Minecraft, reinvented', description: 'Descubre GHOST CLIENT: versiones, descargas y novedades.' };
export default function RootLayout({children}:{children:React.ReactNode}) { return <html lang="es"><body>{children}</body></html>; }
