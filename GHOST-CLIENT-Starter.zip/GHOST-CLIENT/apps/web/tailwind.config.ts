import type { Config } from 'tailwindcss';
const config: Config = { content: ['./src/**/*.{js,ts,jsx,tsx,mdx}'], theme: { extend: { colors: { ghost: { bg: '#07070b', panel: '#11111a', purple: '#9b5cff', violet: '#6d28d9' } }, boxShadow: { glow: '0 0 40px rgba(155,92,255,.18)' } } }, plugins: [] };
export default config;
