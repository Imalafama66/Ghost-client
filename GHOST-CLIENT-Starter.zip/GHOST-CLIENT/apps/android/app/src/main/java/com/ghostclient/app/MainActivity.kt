package com.ghostclient.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { GhostApp() }
    }
}

@Composable
fun GhostApp() {
    val bg = Color(0xFF08080D)
    MaterialTheme(colorScheme = darkColorScheme(
        background = bg, surface = Color(0xFF15121F), primary = Color(0xFF9B5CFF)
    )) {
        Column(
            modifier = Modifier.fillMaxSize().background(
                Brush.verticalGradient(listOf(Color(0xFF171024), bg, bg))
            ).padding(24.dp),
            horizontalAlignment = Alignment.Start,
            verticalArrangement = Arrangement.Center
        ) {
            Text("GHOST CLIENT", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.ExtraBold)
            Text("YOUR GAME. YOUR EXPERIENCE.", color = Color(0xFFB99AFF), fontSize = 11.sp, letterSpacing = 2.sp)
            Spacer(Modifier.height(28.dp))
            Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF171521)), shape = RoundedCornerShape(22.dp)) {
                Column(Modifier.padding(20.dp)) {
                    Text("Bienvenido", color = Color.White, fontSize = 21.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    Text("Consulta versiones, novedades y descargas de GHOST CLIENT desde una sola aplicación.", color = Color.LightGray)
                    Spacer(Modifier.height(20.dp))
                    Button(onClick = { /* Conectar al endpoint real de versiones */ }, modifier = Modifier.fillMaxWidth()) {
                        Text("Explorar versiones")
                    }
                }
            }
            Spacer(Modifier.height(18.dp))
            Text("Versión de la aplicación 0.1.0 · Proyecto inicial", color = Color.Gray, fontSize = 11.sp)
        }
    }
}
