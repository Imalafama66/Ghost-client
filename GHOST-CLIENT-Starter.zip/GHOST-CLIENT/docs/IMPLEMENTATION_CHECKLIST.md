# Checklist antes de producción

## Prioridad crítica
- [ ] Autenticación real, verificación de correo y recuperación.
- [ ] RBAC: proteger `/admin` en middleware y backend.
- [ ] CRUD de usuarios, productos, versiones y changelog.
- [ ] Subida de JAR con validación MIME, tamaño y SHA-256.
- [ ] Almacenamiento privado para Premium.
- [ ] Emisión de URL temporal tras comprobar licencia.
- [ ] Integrar proveedor de pagos que admita los métodos disponibles en México.
- [ ] Verificar pagos mediante webhooks firmados e idempotentes.
- [ ] Crear y revocar licencias desde el servidor.
- [ ] Auditoría de acciones administrativas.
- [ ] Rate limiting, CSRF donde aplique, CSP y validación de entradas.
- [ ] Backups y procedimiento de restauración.
- [ ] Pruebas unitarias, integración y E2E.

## Editor visual
- [ ] Esquema JSON de bloques permitidos.
- [ ] Drag & drop con validación de propiedades.
- [ ] Vista previa responsive.
- [ ] Guardado de borradores.
- [ ] Publicación transaccional y versionado.
- [ ] Restauración de revisiones.

## Android / Play
- [ ] Conectar API y autenticación.
- [ ] Descargas seguras y verificación SHA-256.
- [ ] Política de privacidad y declaración de datos.
- [ ] Icono, capturas, ficha y pruebas internas.
- [ ] Generar AAB firmado con claves fuera del repositorio.
- [ ] Someter a revisión de Google Play; la aprobación no se puede garantizar.
