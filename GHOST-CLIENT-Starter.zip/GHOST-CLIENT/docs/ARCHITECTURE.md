# Arquitectura

La web pública, el administrador y Android consumen una API central. PostgreSQL conserva el estado transaccional; el almacenamiento de objetos conserva los JAR/APK y recursos.

## Principios
- El cliente nunca decide si una compra está pagada.
- El servidor verifica los webhooks y la firma del proveedor.
- Las licencias se validan en servidor.
- Los JAR Premium no tienen URLs públicas permanentes.
- El editor guarda borradores y publicaciones versionadas en la base de datos.
- Las métricas se calculan a partir de eventos reales, no de números escritos en el frontend.

## Próximos módulos
1. Auth + RBAC.
2. CRUD administrativo para productos/versiones.
3. Subida de archivos a almacenamiento S3 compatible.
4. Descargas firmadas y SHA-256.
5. Checkout y webhooks.
6. Emisión, activación y revocación de licencias.
7. CMS/editor visual con borradores y publicación.
8. App Android: sesión, descargas, notificaciones y cuenta.
